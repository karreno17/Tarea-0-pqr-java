package com.visitas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PqrApplicationTests {

	@Test
	void contextLoads() {
	}

}
